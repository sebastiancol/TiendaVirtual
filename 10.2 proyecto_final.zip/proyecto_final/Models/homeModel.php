<?php 

	class homeModel extends Mysql
	{
		public function __construct()
		{
			parent::__construct();
		}	
	}
 ?>